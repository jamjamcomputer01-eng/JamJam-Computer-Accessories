      {/* Login Modal */}
      <AnimatePresence>
        {isLoginOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsLoginOpen(false)}
              className="fixed inset-0 bg-black/80 z-[60] backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className={cn(
                "fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-md z-[60] p-8 rounded-3xl shadow-2xl",
                isDark ? "bg-[#1e1e1e]" : "bg-white"
              )}
            >
              <div className="text-center space-y-4">
                <div className="w-16 h-16 bg-brand/10 text-brand rounded-full flex items-center justify-center mx-auto">
                  <User className="w-8 h-8" />
                </div>
                <h2 className="text-2xl font-black">Welcome Back</h2>
                <p className="text-sm text-gray-500">Login to JamJam Computer to manage your orders</p>
              </div>

              <div className="mt-8 space-y-4">
                <button 
                  onClick={() => {
                    setUser({ name: 'Google User', email: 'user@gmail.com' });
                    setIsLoginOpen(false);
                  }}
                  className={cn(
                    "w-full flex items-center justify-center gap-3 py-3 rounded-xl font-bold border transition-all hover:scale-[1.02]",
                    isDark ? "bg-white text-black border-white" : "bg-white text-gray-800 border-gray-200"
                  )}
                >
                  <svg className="w-5 h-5" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                  </svg>
                  Continue with Google
                </button>

                <button 
                  onClick={() => {
                    setUser({ name: 'Facebook User', email: 'user@fb.com' });
                    setIsLoginOpen(false);
                  }}
                  className="w-full flex items-center justify-center gap-3 py-3 rounded-xl font-bold bg-[#1877F2] text-white transition-all hover:scale-[1.02]"
                >
                  <Facebook className="w-5 h-5 fill-current" />
                  Continue with Facebook
                </button>
              </div>

              <button 
                onClick={() => setIsLoginOpen(false)}
                className="mt-6 w-full text-sm text-gray-500 hover:underline"
              >
                Cancel
              </button>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Checkout Modal */}
      <AnimatePresence>
        {isCheckoutOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCheckoutOpen(false)}
              className="fixed inset-0 bg-black/80 z-[60] backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className={cn(
                "fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-2xl z-[60] p-8 rounded-3xl shadow-2xl overflow-y-auto max-h-[90vh]",
                isDark ? "bg-[#1e1e1e]" : "bg-white"
              )}
            >
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-2xl font-black tracking-tight">CHECKOUT</h2>
                <button onClick={() => setIsCheckoutOpen(false)} className="p-2 hover:bg-gray-800 rounded-full transition-colors">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <h3 className="font-bold text-lg border-b pb-2 border-gray-800">Shipping Details</h3>
                  <div className="space-y-4">
                    <input type="text" placeholder="Full Name" className={cn("w-full p-3 rounded-xl outline-none", isDark ? "bg-[#2a2a2a]" : "bg-gray-100")} />
                    <input type="text" placeholder="Phone Number" className={cn("w-full p-3 rounded-xl outline-none", isDark ? "bg-[#2a2a2a]" : "bg-gray-100")} />
                    <textarea placeholder="Delivery Address" className={cn("w-full p-3 rounded-xl outline-none h-24", isDark ? "bg-[#2a2a2a]" : "bg-gray-100")}></textarea>
                  </div>
                </div>

                <div className="space-y-6">
                  <h3 className="font-bold text-lg border-b pb-2 border-gray-800">Payment Method</h3>
                  <div className="space-y-3">
                    <button 
                      onClick={() => setPaymentMethod('cod')}
                      className={cn(
                        "w-full p-4 rounded-2xl border flex items-center gap-4 transition-all",
                        paymentMethod === 'cod' ? "border-brand bg-brand/10" : "border-gray-800"
                      )}
                    >
                      <div className={cn("w-5 h-5 rounded-full border-2 flex items-center justify-center", paymentMethod === 'cod' ? "border-brand" : "border-gray-500")}>
                        {paymentMethod === 'cod' && <div className="w-2.5 h-2.5 rounded-full bg-brand" />}
                      </div>
                      <div className="text-left">
                        <p className="font-bold">Cash on Delivery</p>
                        <p className="text-xs text-gray-500">Pay when you receive the product</p>
                      </div>
                    </button>

                    <button 
                      onClick={() => setPaymentMethod('advance')}
                      className={cn(
                        "w-full p-4 rounded-2xl border flex items-center gap-4 transition-all",
                        paymentMethod === 'advance' ? "border-brand bg-brand/10" : "border-gray-800"
                      )}
                    >
                      <div className={cn("w-5 h-5 rounded-full border-2 flex items-center justify-center", paymentMethod === 'advance' ? "border-brand" : "border-gray-500")}>
                        {paymentMethod === 'advance' && <div className="w-2.5 h-2.5 rounded-full bg-brand" />}
                      </div>
                      <div className="text-left">
                        <p className="font-bold">Advance Payment</p>
                        <p className="text-xs text-gray-500">Pay via bKash/Nagad for faster delivery</p>
                      </div>
                    </button>
                  </div>

                  {paymentMethod === 'advance' && (
                    <motion.div 
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="p-4 bg-brand/5 rounded-2xl border border-brand/20 space-y-2"
                    >
                      <p className="text-xs font-bold text-brand uppercase tracking-wider">Payment Instruction</p>
                      <p className="text-sm">Please send the total amount to:</p>
                      <p className="font-black text-lg">01309327668 (bKash/Nagad)</p>
                      <p className="text-xs text-gray-500 italic">Use your phone number as reference.</p>
                    </motion.div>
                  )}

                  <div className="pt-4 border-t border-gray-800">
                    <div className="flex justify-between items-center mb-4">
                      <span className="font-bold">Total Amount:</span>
                      <span className="text-brand font-black text-2xl">৳{cartTotal}</span>
                    </div>
                    <button 
                      onClick={() => {
                        alert('Order placed successfully! We will contact you soon.');
                        setCart([]);
                        setIsCheckoutOpen(false);
                      }}
                      className="w-full bg-brand text-white py-4 rounded-2xl font-black hover:bg-brand-dark transition-all shadow-xl shadow-brand/30"
                    >
                      CONFIRM ORDER
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
